import gymnasium as gym
import numpy as np
import random
import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque
import time
from gymnasium.envs.toy_text.frozen_lake import generate_random_map
from stable_baselines3 import DQN
from stable_baselines3.common.env_util import make_vec_env
#API AIzaSyArmkh3OmJZ11vU3c6zPu-J841qi2HIW64

import google.generativeai as genai

genai.configure(api_key="AIzaSyArmkh3OmJZ11vU3c6zPu-J841qi2HIW64")
GEMINI_MODEL = genai.GenerativeModel("models/gemini-1.0-pro")
USE_LLM_REWARD = False

# ---------------------------------------------------------
# 1. STABLE-BASELINES3
# ---------------------------------------------------------

class FrozenLakeCustomWrapper(gym.ObservationWrapper):
    def __init__(self, env):
        super().__init__(env)
        self.size = env.unwrapped.desc.shape[0]

        # 3x3 celdas × 4 tipos (S,F,H,G)
        self.observation_space = gym.spaces.Box(
            low=0.0,
            high=1.0,
            shape=(3 * 3 * 4,),
            dtype=np.float32
        )

    def observation(self, obs):
        r = obs // self.size
        c = obs % self.size

        features = []

        for dr in [-1, 0, 1]:
            for dc in [-1, 0, 1]:
                rr, cc = r + dr, c + dc

                if 0 <= rr < self.size and 0 <= cc < self.size:
                    cell = self.env.unwrapped.desc[rr][cc]
                    cell = cell.decode("utf-8") if isinstance(cell, bytes) else cell
                else:
                    cell = "H"  # fuera del mapa = peligro

                # one-hot: [S, F, H, G]
                features.extend([
                    float(cell == "S"),
                    float(cell == "F"),
                    float(cell == "H"),
                    float(cell == "G"),
                ])

        return np.array(features, dtype=np.float32)
    

class FrozenLakeRewardWrapper(gym.RewardWrapper):
    def __init__(self, env):
        super().__init__(env)
        self.size = env.unwrapped.desc.shape[0]
        self.last_dist = None

    def reset(self, **kwargs):
        obs, info = self.env.reset(**kwargs)
        r = obs // self.size
        c = obs % self.size
        self.last_dist = abs(self.size - 1 - r) + abs(self.size - 1 - c)
        return obs, info

    def reward(self, reward):
        state = self.env.unwrapped.s
        r = state // self.size
        c = state % self.size

        cell = self.env.unwrapped.desc[r][c]
        if isinstance(cell, bytes):
            cell = cell.decode("utf-8")

        # Éxito
        if reward == 1:
            return 50.0

        # Agujero
        if cell == "H":
            return -50.0

        # Progreso hacia la meta
        dist = abs(self.size - 1 - r) + abs(self.size - 1 - c)
        delta = self.last_dist - dist
        self.last_dist = dist

        return 1.0 * delta - 0.05

class FrozenLakeLLMRewardWrapper(gym.Wrapper):
    def __init__(self, env, size, model_ai, max_llm_steps=50_000):
        super().__init__(env)
        self.size = size
        self.model_ai = model_ai
        self.last_obs = None
        self.step_count = 0
        self.max_llm_steps = max_llm_steps

    def reset(self, **kwargs):
        obs, info = self.env.reset(**kwargs)
        self.last_obs = obs
        return obs, info

    def step(self, action):
        obs, reward, terminated, truncated, info = self.env.step(action)
        self.step_count += 1

        #  Apagar LLM tras cierto número de pasos
        if self.last_obs is not None:
            try:
                fila_prev = int(self.last_obs) // self.size
                col_prev  = int(self.last_obs) % self.size
                fila      = int(obs) // self.size
                col       = int(obs) % self.size

                # ----------------------------
                # CONFIGURACIÓN LLM REWARD
                # ----------------------------
                if self.size == 4:
                    usar_llm = random.random() < 0.3   # fuerte en 4x4
                    peso_llm = 0.1
                else:  # size == 8
                    usar_llm = random.random() < 0.1   # débil en 8x8
                    peso_llm = 0.05

                if usar_llm:
                    # 🔑 POTENTIAL-BASED SHAPING (policy invariant)
                    phi_prev = potencial(fila_prev, col_prev, self.size)
                    phi_curr = potencial(fila, col, self.size)

                    reward += peso_llm * (phi_curr - phi_prev)

            except Exception:
                pass  # si el LLM falla, seguimos

        self.last_obs = obs
        return obs, reward, terminated, truncated, info
    

# ---------------------------------------------------------
# 3. ENTRENAMIENTO
# ---------------------------------------------------------

def entrenar_con_sb3(size, total_timesteps=1_000_000, use_llm_reward=False):
    mapas = crear_pool_entrenamiento(size)

    def make_env():
        mapa = random.choice(mapas)
        env = gym.make("FrozenLake-v1", desc=mapa, is_slippery=False)
        env = FrozenLakeRewardWrapper(env)
        env = FrozenLakeCustomWrapper(env)

        if use_llm_reward:
            env = FrozenLakeLLMRewardWrapper(env, size, client_local)

        return env

    env = make_vec_env(make_env, n_envs=4)

    model = DQN(
        "MlpPolicy",
        env,
        learning_rate=2.5e-4,
        buffer_size=300_000,
        learning_starts=2_000,
        batch_size=128,
        gamma=0.995,
        train_freq=1,
        gradient_steps=2,
        exploration_fraction=0.25,
        exploration_final_eps=0.02,
        target_update_interval=1_000,
        verbose=1,
    )

    model.learn(total_timesteps=total_timesteps)
    env.close()
    return model


# ---------------------------------------------------------
# 2. SISTEMA DE RECOMPENSAS Y MAPAS 
# ---------------------------------------------------------
def crear_pool_entrenamiento(size, n=40):
    mapas = []

    # Fáciles
    for _ in range(n // 4):
        mapas.append(generate_random_map(size=size, p=0.95))

    # Medios
    for _ in range(n // 2):
        mapas.append(generate_random_map(size=size, p=0.90))

    # Difíciles
    for _ in range(n // 4):
        mapas.append(generate_random_map(size=size, p=0.85))

    return mapas

def calcular_recompensa_personalizada(state, size, reward_gym, terminated):
    if terminated:
        return 100 if reward_gym == 1 else -100
    r, c = state // size, state % size
    dist_manhattan = (size - 1 - r) + (size - 1 - c)
    return -1 - (dist_manhattan * 0.1) 


# ---------------------------------------------------------
# 4. LARGE LANGUAGE MODELS (LLMs)
# ---------------------------------------------------------

def obtener_descripcion_estado(state, size, mapa):
    fila = state // size
    columna = state % size
    
    desc = f"Estás en la fila {fila}, columna {columna} (Casilla {state}).\n"
    
    movimientos = {
        "Abajo": (fila + 1, columna, 1),
        "Derecha": (fila, columna + 1, 2),
        "Izquierda": (fila, columna - 1, 0),
        "Arriba": (fila - 1, columna, 3)
    }
    
    for direccion, (f, c, action) in movimientos.items():
        # Inicializamos tipo con un valor por defecto para evitar el error
        tipo = "" 
        
        if 0 <= f < size and 0 <= c < size:
            contenido = mapa[f][c]
            tipo = "HIELO" if contenido == 'F' else "AGUJERO" if contenido == 'H' else "META" if contenido == 'G' else "SALIDA"
            desc += f"- Al {direccion}: {tipo}\n"
        else:
            tipo = "MURO"
            desc += f"- {direccion}: MURO (¡Acción {action} INVÁLIDA!)\n"
            
        # Ahora 'tipo' siempre existe, así que esta comparación no fallará
        if tipo == "MURO":
            desc += f"  ADVERTENCIA: No elijas la acción {action}.\n"
            
    return desc



# Configura tu API Key de Google aquí




def llamar_gemini(prompt: str) -> str:
    try:
        response = GEMINI_MODEL.models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt,
        )
        return response.text if response and response.text else ""
    except Exception as e:
        print("[GEMINI ERROR]", e)
        return ""


def obtener_acciones_seguras(mapa, fila, col, size):
    """
    Devuelve una lista de acciones seguras desde (fila, col)
    teniendo en cuenta límites y agujeros.
    """
    acciones = []
    movimientos = {
        0: (0, -1),   # izquierda
        1: (1, 0),    # abajo
        2: (0, 1),    # derecha
        3: (-1, 0)    # arriba
    }

    for accion, (dr, dc) in movimientos.items():
        nr, nc = fila + dr, col + dc

        if not (0 <= nr < size and 0 <= nc < size):
            continue

        celda = mapa[nr][nc]
        if isinstance(celda, bytes):
            celda = celda.decode("utf-8")

        if celda != "H":
            acciones.append(accion)

    return acciones


def obtener_radar_llm(mapa, fila, col, size):
    nombres = {'S': 'Seguro', 'F': 'Seguro', 'H': 'AGUJERO', 'G': 'META'}
    
    def get_info(f, c):
        if 0 <= f < size and 0 <= c < size:
            char = mapa[f][c]
            # Convertimos a string si es necesario para comparar
            char_str = char.decode('utf-8') if isinstance(char, bytes) else str(char)
            return nombres.get(char_str, "Desconocido")
        return "MURO"

    return {
        "Norte (Arriba)": get_info(fila - 1, col),
        "Sur (Abajo)": get_info(fila + 1, col),
        "Este (Derecha)": get_info(fila, col + 1),
        "Oeste (Izquierda)": get_info(fila, col - 1)
    }


def formatear_mapa_texto(mapa):
    """Convierte el mapa a texto, manejando tanto bytes como strings."""
    filas_texto = []
    for row in mapa:
        celdas = []
        for cell in row:
            # Si es byte (b'F'), lo decodificamos. Si es str ('F'), lo dejamos igual.
            if isinstance(cell, bytes):
                celdas.append(cell.decode('utf-8'))
            else:
                celdas.append(str(cell))
        filas_texto.append(" ".join(celdas))
    return "\n".join(filas_texto)


# Añade esta variable global al principio de tu script (fuera de las funciones)
ultimo_movimiento = None

def pedir_accion_llm(mapa, fila, col, size, model_ai, es_gemini=True):
    global ultimo_movimiento

    radar = obtener_radar_llm(mapa, fila, col, size)
    mapa_txt = formatear_mapa_texto(mapa)
    acciones_seguras = obtener_acciones_seguras(mapa, fila, col, size)

    acciones_txt = ", ".join(str(a) for a in acciones_seguras)

    prompt = f"""
Eres un agente experto en FrozenLake.

OBJETIVO:
Llegar a la meta (G) evitando agujeros (H).

MAPA:
{mapa_txt}

POSICIÓN ACTUAL: ({fila}, {col})
META: ({size - 1}, {size - 1})

ACCIONES SEGURAS DISPONIBLES:
{acciones_txt}

INFORMACIÓN LOCAL:
Arriba: {radar['Norte (Arriba)']}
Abajo: {radar['Sur (Abajo)']}
Derecha: {radar['Este (Derecha)']}
Izquierda: {radar['Oeste (Izquierda)']}

ACCIONES:
0 = izquierda
1 = abajo
2 = derecha
3 = arriba

Responde SOLO con un número.
"""

    try:
        # 🔹 MISMO BACKEND, DISTINTA POLÍTICA
        temp = 0.6 if es_gemini else 0.1

        completion = model_ai.chat.completions.create(
            model="llama-3.2-1b-instruct",
            messages=[{"role": "user", "content": prompt}],
            temperature=temp
        )
        texto = completion.choices[0].message.content.strip()

        match = re.search(r"[0-3]", texto)
        accion = int(match.group()) if match else random.choice(acciones_seguras)

        # ✅ Validación dura (ambos)
        if accion not in acciones_seguras:
            accion = random.choice(acciones_seguras)

        # ✅ Anti-loop SOLO LLM local
        if not es_gemini and ultimo_movimiento is not None:
            opuestos = {0: 2, 2: 0, 1: 3, 3: 1}
            if accion == opuestos.get(ultimo_movimiento):
                accion = random.choice(acciones_seguras)

        if size == 8 and not es_gemini:
            if random.random() < 0.2:
                accion = random.choice(acciones_seguras)

        ultimo_movimiento = accion
        return accion

    except Exception as e:
        print("[ERROR LLM]:", e)
        return random.choice(acciones_seguras)

from openai import OpenAI
import re

# Configuración del cliente para LM Studio (según tu imagen)
client_local = OpenAI(base_url="http://localhost:1234/v1", api_key="lm-studio")

def pedir_accion_llm_local(mapa, fila, col, size):
    return pedir_accion_llm(
        mapa, fila, col, size,
        model_ai=client_local,
        es_gemini=False
    )
# ---------------------------------------------------------
# 5. EVALUACIÓN Y DEMO (REQUISITOS USUARIO)
# ---------------------------------------------------------
def calcular_accuracy_sb3(modelo, size, n_tests=50):
    exitos = 0

    # ✅ definir max_pasos REAL
    if size == 8:
        max_pasos = 4 * size * size   # 256
    else:
        max_pasos = size * size       # 16

    for _ in range(n_tests):
        mapa = generate_random_map(size=size, p=0.9)
        env = gym.make("FrozenLake-v1", desc=mapa, is_slippery=False)
        env = FrozenLakeCustomWrapper(env)
        obs, _ = env.reset()

        done = False
        pasos = 0

        # ✅ usar max_pasos en el while
        while not done and pasos < max_pasos:
            action, _ = modelo.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, _ = env.step(int(action))
            done = terminated or truncated
            pasos += 1

            if done and reward == 1:
                exitos += 1

        env.close()

    return 100 * exitos / n_tests

def reward_llm(mapa, fila, col, fila_prev, col_prev, size, model_ai):
    """
    LLM como reward model: evalúa si el movimiento fue bueno o malo.
    Devuelve un valor pequeño: -1, 0 o +1
    """
    prompt = f"""
Eres un evaluador de decisiones en FrozenLake.

Estado anterior: ({fila_prev}, {col_prev})
Estado actual: ({fila}, {col})
Meta: ({size-1}, {size-1})

Evalúa el movimiento según estas reglas:
- +1 si se acerca a la meta y es seguro
- 0 si no aporta información clara
- -1 si se aleja de la meta o es peligroso

Responde SOLO con un número: -1, 0 o 1.
"""

    try:
        completion = model_ai.chat.completions.create(
            model="llama-3.2-1b-instruct",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.0
        )
        text = completion.choices[0].message.content.strip()
        return int(text) if text in ["-1", "0", "1"] else 0
    except:
        return 0



def potencial(fila, col, size):
    """
    Potencial simple basado en distancia Manhattan a la meta.
    Más cerca de la meta => mayor potencial.
    """
    return - (abs(size - 1 - fila) + abs(size - 1 - col))



def calcular_accuracy_llm(size, n_tests=10, modo="gemini"):
    exitos = 0
    # Probabilidad de suelo seguro (no de agujero)
    p_safe = 0.85 if size == 4 else 0.92   
    if size == 8:
        max_pasos = 4 * size * size   # 256 pasos
    else:
        max_pasos = size * size


    print(f"\n--- Evaluando LLM ({modo}) en {n_tests} mapas nuevos ({size}x{size}) ---")

    global ultimo_movimiento

    for i in range(n_tests):
        m = generate_random_map(size=size, p=p_safe)
        env = gym.make("FrozenLake-v1", desc=m, is_slippery=False)

        obs, _ = env.reset()
        done = False
        pasos = 0
        reward = 0

        # ✅ reset ANTI-LOOP UNA VEZ POR EPISODIO
        ultimo_movimiento = None

        while not done and pasos < max_pasos:
            fila = obs // size
            col = obs % size

            if modo == "local":
                action = pedir_accion_llm_local(m, fila, col, size)
            else:
                action = pedir_accion_llm(m, fila, col, size,model_ai=client_local,es_gemini=True)

            obs, reward, term, trunc, _ = env.step(action)
            done = term or trunc
            pasos += 1

        #  criterio de éxito correcto
        if reward == 1:
            exitos += 1
            print(f" Partida {i+1}: LOGRADO")
        else:
            print(f" Partida {i+1}: FALLIDO")

        env.close()

    return (exitos / n_tests) * 100


def calcular_accuracy_mapas_conocidos(modelo, size, mapas, n_tests=50):
    exitos = 0

    # ✅ definir max_pasos REAL
    if size == 8:
        max_pasos = 4 * size * size
    else:
        max_pasos = size * size

    for _ in range(n_tests):
        mapa = random.choice(mapas)
        env = gym.make("FrozenLake-v1", desc=mapa, is_slippery=False)
        env = FrozenLakeCustomWrapper(env)
        obs, _ = env.reset()

        done = False
        pasos = 0

        # ✅ usar max_pasos
        while not done and pasos < max_pasos:
            action, _ = modelo.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, _ = env.step(int(action))
            done = terminated or truncated
            pasos += 1

            if done and reward == 1:
                exitos += 1

        env.close()

    return 100 * exitos / n_tests





# ---------------------------------------------------------
# TABLA PARA COMPARAR MODELOS
# ---------------------------------------------------------

def generar_tabla_comparativa(size,acc_base_pool,acc_llm_pool,acc_base_new,acc_llm_new):
    print("\n" + "=" * 80)
    print(f"RESULTADOS RL – FROZEN LAKE {size}x{size}")
    print("=" * 80)
    print(f"{'MÉTODO':<25} {'ESCENARIO':<20} {'ACCURACY (%)':<15} {'OBSERVACIÓN'}")
    print("-" * 80)

    print(f"{'DQN baseline':<25} {'Pool':<20} {acc_base_pool:<15.2f} {'Sin LLM'}")
    print(f"{'DQN + LLM reward':<25} {'Pool':<20} {acc_llm_pool:<15.2f} {'Reward shaping'}")

    print("-" * 80)

    print(f"{'DQN baseline':<25} {'Mapas nuevos':<20} {acc_base_new:<15.2f} {'Generalización'}")
    print(f"{'DQN + LLM reward':<25} {'Mapas nuevos':<20} {acc_llm_new:<15.2f} {'Generalización + LLM'}")

    print(f"{'Gemini 1.5 Flash (Cloud)':<35} | {res_gemini:<15.2f} | {'Zero-Shot'}")
    print(f"{'Llama 3.2 1B (Local)':<35} | {res_llama:<15.2f} | {'Zero-Shot'}")
    
    print("=" * 80)
# ---------------------------------------------------------
# MAIN
# ---------------------------------------------------------
if __name__ == "__main__":
    
    SEED = 42
    random.seed(SEED)
    np

    print("=== SISTEMA DE COMPARATIVA FROZEN LAKE (SB3 + LLMs) ===")
    
    # 1. Selección inicial y entrenamiento
    print("\nPara empezar, entrenaremos el modelo DQN profesional (SB3).")
    print("1. Mapa 4x4")
    print("2. Mapa 8x8")
    modo_size = input("Selecciona tamaño (1 o 2): ")
    
    size = 4 if modo_size == "1" else 8 
    total_timesteps=300000
    modelo_dqn_base = entrenar_con_sb3(size, total_timesteps, use_llm_reward=False)

    # Con LLM reward
    modelo_dqn_llm = entrenar_con_sb3(size, total_timesteps*0.4, use_llm_reward=True)

    # Creamos el pool para las evaluaciones
    pool_entrenamiento = crear_pool_entrenamiento(size)
    
    # Inicializamos variables de la tabla
    res_dqn_nuevo, res_dqn_pool, res_gemini, res_llama = 0, 0, 0, 0

    while True:
        print(f"\n" + "="*45)
        print(f" MENÚ DE COMPARATIVA SB3 - MAPA {size}x{size}")
        print("="*45)
        print("1. Evaluar DQN (Accuracy Pool y Nuevos)")
        print("2. Evaluar GEMINI (Cloud)")
        print("3. Evaluar LLM LOCAL (LM Studio)")
        print("4. Cambiar Tamaño de Mapa (Reinicia todo)")
        print("0. Salir")
        print("T. Ver Tabla Comparativa")
        print("-" * 45)
        
        opcion = input("Selecciona una opción: ").upper()

        if opcion == "1":
            print(f"\n[DQN] Evaluando rendimiento...")
            
            # --- EVALUACIÓN MAPAS NUEVOS ---
            if size == 8:
                modelo_dqn_base.exploration_rate = 0.02   # pequeño epsilon residual
            else:
                modelo_dqn_base.exploration_rate = 0.0
            acc_base_new = calcular_accuracy_sb3(modelo_dqn_base, size)
            acc_llm_new = calcular_accuracy_sb3(modelo_dqn_llm, size)
       
            # --- EVALUACIÓN POOL ---
            exitos_p = 0
            for i, mapa in enumerate(pool_entrenamiento):
                env_p = gym.make("FrozenLake-v1", desc=mapa, is_slippery=False)
                env_p = FrozenLakeCustomWrapper(env_p)
                
                # RESET: Cogemos solo el primer valor (la observación)
                obs, _ = env_p.reset() 
                done = False
                pasos = 0
                while not done and pasos < 50:
                    # Forzamos a float32 y quitamos dimensiones extra
                    obs_input = np.array(obs, dtype=np.float32)
                    action, _ = modelo_dqn_base.predict(obs_input, deterministic=True)
                    if pasos < 3: # Solo los primeros pasos para no inundar la consola
                        print(f"Mapa {i} - Paso {pasos}: Estado {obs} -> Acción elegida {action.item()}")
                    obs, reward, term, trunc, _ = env_p.step(action.item())
                    done = term or trunc
                    pasos += 1
                
                if reward == 1: 
                    exitos_p += 1
                    done=True
                else:
                    done = term or trunc
                env_p.close()
            
            
                acc_base_pool = calcular_accuracy_mapas_conocidos(modelo_dqn_base, size, pool_entrenamiento)
                acc_llm_pool = calcular_accuracy_mapas_conocidos(modelo_dqn_llm, size, pool_entrenamiento)

                
                print("\n=== COMPARACIÓN DQN vs DQN + LLM REWARD ===")

                print(f"\nMAPAS DEL POOL ({size}x{size})")
                print(f"DQN baseline:       {acc_base_pool:.2f} %")
                print(f"DQN + LLM reward:   {acc_llm_pool:.2f} %")

                print(f"\nMAPAS NUEVOS ({size}x{size})")
                print(f"DQN baseline:       {acc_base_new:.2f} %")
                print(f"DQN + LLM reward:   {acc_llm_new:.2f} %")


        elif opcion == "2":
            print(f"\n[GEMINI] Evaluando en mapas nuevos...")
            res_gemini = calcular_accuracy_llm(size, n_tests=20, modo="gemini")
            print(f">>> ACCURACY GEMINI: {res_gemini}%")

        elif opcion == "3":
            print(f"\n[LOCAL] Evaluando Llama 3.2")
            res_llama = calcular_accuracy_llm(size, n_tests=20, modo="local")
            print(f">>> ACCURACY LOCAL: {res_llama}%")

        
        elif opcion == "4":
            print("\nReiniciando con nuevo tamaño...")
            modo_size = input("1. Mapa 4x4\n2. Mapa 8x8\nSelección: ")
            size = 4 if modo_size == "1" else 8           
            if size == 4:
                total_timesteps = 200_000
            else:  # size == 8
                total_timesteps = 450_000
            modelo_sb3 = entrenar_con_sb3(size, total_timesteps=total_timesteps)

            pool_entrenamiento = crear_pool_entrenamiento(size)
            res_dqn_nuevo, res_dqn_pool, res_gemini, res_llama = 0, 0, 0, 0

        elif opcion == "T":
            generar_tabla_comparativa(size,acc_base_pool,acc_llm_pool,acc_base_new,acc_llm_new)


        elif opcion == "0":
            print("Saliendo...")
            break
        
        else:
            print("[!] Opción no válida.")



